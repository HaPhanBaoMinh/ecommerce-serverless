# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from stripe.test_helpers.terminal._reader_service import (
    ReaderService as ReaderService,
)
