from typing_extensions import Literal


ApiMode = Literal["V1", "V2"]
